﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EWSEditor.Forms
{
    public partial class ListActiveSyncDevices : Form
    {
        public ListActiveSyncDevices()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // http://gsexdev.blogspot.com/2013/11/mapping-what-folders-are-in-use-in.html
            // http://gsexdev.blogspot.com/2006/09/enumerating-devices-registered-via.html

        }
    }
}
