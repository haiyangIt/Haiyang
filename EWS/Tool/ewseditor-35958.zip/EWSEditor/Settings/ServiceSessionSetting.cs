﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EWSEditor.Settings
{

    // This is not used yet - will incoperate for saving and loading service session profiles
    // Items below were commented out for now so that they don't generate warnings since they are not used currently
    public class ServiceSessionSetting
    {

        //public string ExchangeSchemaVersion = string.Empty;
        //public string MailboxBeingAccessed = string.Empty;
        //public string AuthenticationMethod = string.Empty;  // Default, UserSpecified, oAuth



        //string AutodiscoverEmailText = string.Empty;
        //bool AutodiscoverEmailTextSelected = true;
        //string ExchangeServiceURLText = string.Empty;
        //bool ExchangeServiceURLTextSelected = false;
        //string ExchangeVersion = string.Empty;
        //bool UseSpecifiedCredentialsSelected = false;
        //string UserName = string.Empty;
        //string Password = string.Empty;
        //string Domain = string.Empty;
        //bool UseImpersonationSelected = false;
        //string IDType = string.Empty;
        //string Id = string.Empty;
        //bool UseSpecifiedTimezone = false;
        //string UseTimeZone = string.Empty;

        //// These override the user/global settings stored in the UserSettings file when a new session is created.
        //string UserAgentValue = string.Empty;
        //bool OverrideSslCheck = false;
        //bool EnableSslDetailCheck = false;
        //bool AllowRedirectsCheck = false;
        //bool EnableScpLookups = false;
        //string CalendarViewSize = string.Empty;
        //string FindFolderViewSize = string.Empty;
        //string FindItemViewSize = string.Empty;
        //string DumpFolder = string.Empty;
        //bool SaveLogFile = false;
        //string LogFilePathText = string.Empty;

        // txtOAuthRedirectUri
        // txtOAuthAppId
        // txtOAuthServerName
        // txtOAuthAuthority


    }
}

 

 
                //EwsProxyFactory.UseDefaultCredentials = this.rdoCredentialsDefaultWindows.Checked;
                //EwsProxyFactory.CredentialsUserSpecified = this.rdoCredentialsUserSpecified.Checked;
                //EwsProxyFactory.UseoAuth = this.rdoCredentialsOAuth.Checked;
                //EwsProxyFactory.oAuthRedirectUrl = this.txtOAuthRedirectUri.Text.Trim();
                //EwsProxyFactory.oAuthClientId = this.txtOAuthAppId.Text.Trim();
                //EwsProxyFactory.oAuthServerName = this.txtOAuthServerName.Text.Trim();
                //EwsProxyFactory.oAuthAuthority = this.txtOAuthAuthority.Text.Trim();
