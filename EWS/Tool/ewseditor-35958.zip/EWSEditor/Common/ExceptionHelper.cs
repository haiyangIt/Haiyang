﻿namespace EWSEditor.Common
{
    using System;

    public class ExceptionHelper
    {
        public const string ExchangeServiceRequiredMessage = "This form requires a valid ExchangeService because it makes EWS requests.";
    }
}
