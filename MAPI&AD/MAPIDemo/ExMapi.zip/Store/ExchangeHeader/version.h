#define rmj		4
#define rmm		730
#define rup		0
#define szVerName	""
#define szVerUser	"TDSRC"
