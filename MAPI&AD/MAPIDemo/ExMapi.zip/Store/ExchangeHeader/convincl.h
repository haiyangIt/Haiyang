// --convincl.h-----------------------------------------------------------------
// 
// Conversion inclues.
//
// Copyright (C) Microsoft Corp. 1986-1996.  All Rights Reserved.
//
// -----------------------------------------------------------------------------

#if !defined(_CONVINCL_H)
#define _CONVINCL_H

#define _MEMLOG_H

#include "edk.h"

#ifdef __cplusplus
#include "convdllc.h"
#include "convdlle.h"
#include "convdll.h"
#include "convregh.h"
#include "convclss.h"
#include "convreg.h"
#include "convengn.h"
#endif
#include "convcwrp.h"

#endif
